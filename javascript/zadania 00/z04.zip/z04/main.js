
let a = prompt("Podaj liczbe a: ","0");
a = parseInt(a);
let b = prompt("Podaj liczbe b: ","0");
b = parseInt(b);


let iloraz = a/b;


document.write("<b>",a,":",b,"=",iloraz.toFixed(2),"</b><br>");

doc



console.log(iloraz);